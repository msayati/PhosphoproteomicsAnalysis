#' Cleans the data
#'
#' Takes a directory name to an excel sheet and cleans it. Requires readxl package. Will create a .csv file in the same directory.
#' @param bcd Directory of the excel file name
#' @param sh Page in your excel sheet where the information is located
#' @param threshold Amount of NAs you want to remove, from 0 to 1
#' @return A clean BCD of the data input.

# function to clean user data given the file location as a string
clean.bcd<-function(bcd, sh, threshold){

  #reads in excel file
  UncleanData <- read_excel(bcd,sheet = as.numeric(sh))

  #appends .csv for your file name
  csvFilename <- c(bcd, ".csv")
  csvFilename <- paste(csvFilename, collapse = "")

  #converts it into csv file in the same directory
  write.csv(UncleanData,csvFilename,row.names=FALSE)

  #reads in csv file
  UncleanData <- read.csv(csvFilename)

  #creating a dataframe cleanBCD to store the columns that have more
  #less than 40%NA
  cleanBCD <- UncleanData[ lapply( UncleanData, function(cleanBCD) sum(is.na(cleanBCD)) / length(cleanBCD) ) < as.numeric(threshold) ]

  #delete rows with NA
  cleanBCD <- cleanBCD[complete.cases(cleanBCD), ]

  return(cleanBCD)
}


#https://github.com/hadley/requirements
#https://www.youtube.com/watch?v=9PyQlbAEujY
#devtools
#roxygen
